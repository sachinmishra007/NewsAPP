﻿


angular.module("NewsAPI.controllers", [])
    .controller("NewsAPIController", function ($scope, $document, $q, $window, $interval, $timeout, $log, NewsAPIKey, NewsAPIServices) {

        $scope.NewsAPISource = {};
        $scope.NewsAPISourceContent = {};

        $scope.LogMe = function (_strMessageToLog) {
            $log.debug("Log Message : " + _strMessageToLog);
        };

        NewsAPIServices
        .GetNewsAPISource()
        .success(function (_result) {
            $scope.NewsAPISource = _result;
        })
        .error(function (_error) {
            $scope.LogMe(_error);
        });


        $scope.GetNewsContentData = function (_sourceName) {
            NewsAPIServices
        .GetNewsJsonDataFromSource(_sourceName)
        .success(function (_result) {
            $scope.NewsAPISourceContent = _result.articles;
            $log.info($scope.NewsAPISourceContent);
        })
        .error(function (_error) {
            $scope.LogMe(_error);
        });
        };



    });